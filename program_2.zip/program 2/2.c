#include <stdio.h>

int main()
{
    float l,b,p,a;
    int num;

    printf("Enter the number of plots ou want to estimte area and perimeter along with cost of fencing and grass laying :  \n");
    scanf("%d",&num);

    for(int i = 1; i<=num;i++)
    {
        printf("\nFor plot : %d \n",i);
        printf("Enter Length (in m) :");
    scanf("%f",&l);

    printf("\nEnter Breadth (in m) : ");
    scanf("%f",&b);

    p= 2 * (l + b);

    printf("\nperimeter is : %f",p);

    a = l * b;

    printf("\narea is : %f",a);
    }



    return 0;

}
